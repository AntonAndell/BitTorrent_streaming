STATES = ['Queued', 'Checking', 'Downloading torrent metadata', 'Downloading',
          'Finished', 'Seeding', 'Allocating']
